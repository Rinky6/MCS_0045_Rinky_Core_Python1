def cong(n):
    for i in range(1,n +1):
        print(i , end="")

n=int(input("Enter the integer no : "))
cong(n)